# Changelog

All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.0.1
- Fixed the default video path being "%USER\Videos\Content Warning"

## 1.0.0
- Initial Release